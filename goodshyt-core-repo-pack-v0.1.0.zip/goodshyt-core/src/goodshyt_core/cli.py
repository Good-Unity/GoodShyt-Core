import pathlib
import typer
from .metrics import compute_gmi
from .models import GMIRequest
from .policies import load_policy_from_yaml, validate_policy

app = typer.Typer(help="GoodShyt Core CLI")

@app.command()
def score(ecti: float, csm: float, stl: float, kaq: float) -> None:
    payload = GMIRequest(ecti=ecti, csm=csm, stl=stl, kaq=kaq)
    typer.echo(compute_gmi(payload))

@app.command()
def validate(policy_path: str) -> None:
    data = pathlib.Path(policy_path).read_text(encoding="utf-8")
    policy = load_policy_from_yaml(data)
    errors = validate_policy(policy)
    if errors:
        for error in errors:
            typer.echo(error)
        raise typer.Exit(code=1)
    typer.echo(f"Policy valid: {policy.metric}")

if __name__ == "__main__":
    app()

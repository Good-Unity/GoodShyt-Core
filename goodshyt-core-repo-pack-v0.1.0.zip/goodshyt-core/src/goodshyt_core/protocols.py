from .models import HandshakeRequest, HandshakeResponse

def verify_handshake(payload: HandshakeRequest) -> HandshakeResponse:
    ok = bool(payload.service_name.strip()) and bool(payload.supported_metrics) and bool(payload.policy_bundle_hash.strip())
    normalized = payload.service_name.strip().lower().replace(" ", "-")
    message = "Handshake accepted." if ok else "Handshake rejected."
    return HandshakeResponse(accepted=ok, message=message, normalized_service=normalized)

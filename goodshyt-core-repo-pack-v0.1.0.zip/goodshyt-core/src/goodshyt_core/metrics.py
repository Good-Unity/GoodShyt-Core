from .models import GMIRequest, MetricScore

def compute_gmi(payload: GMIRequest) -> float:
    stl_inverted = max(0.0, min(1.0, 1.0 - payload.stl))
    raw = (payload.ecti * 0.30) + (payload.csm * 0.30) + (stl_inverted * 0.20) + (payload.kaq * 0.20)
    return round(raw, 4)

def classify(name: str, value: float) -> MetricScore:
    status = "pass" if value >= 0.9 else "warn" if value >= 0.75 else "fail"
    explanation = (
        "Aligned and production-healthy."
        if status == "pass"
        else "Operationally acceptable but improvable."
        if status == "warn"
        else "Intervention recommended."
    )
    return MetricScore(name=name, value=value, status=status, explanation=explanation)

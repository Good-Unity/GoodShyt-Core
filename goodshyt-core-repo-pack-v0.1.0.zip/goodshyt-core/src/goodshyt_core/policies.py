import yaml
from .models import EthicsPolicy

def load_policy_from_yaml(policy_yaml: str) -> EthicsPolicy:
    data = yaml.safe_load(policy_yaml)
    return EthicsPolicy.model_validate(data)

def validate_policy(policy: EthicsPolicy) -> list[str]:
    errors: list[str] = []
    metric = policy.metric.upper()
    if metric == "ECTI" and policy.thresholds.min_fidelity is None:
        errors.append("ECTI requires thresholds.min_fidelity.")
    if metric == "STL" and policy.thresholds.max_latency_ms is None:
        errors.append("STL requires thresholds.max_latency_ms.")
    if metric == "CSM" and policy.thresholds.min_synergy is None:
        errors.append("CSM requires thresholds.min_synergy.")
    if metric == "KAQ" and policy.thresholds.min_alignment is None:
        errors.append("KAQ requires thresholds.min_alignment.")
    return errors

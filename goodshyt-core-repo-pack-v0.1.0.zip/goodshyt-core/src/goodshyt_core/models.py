from typing import Literal
from pydantic import BaseModel, Field

MetricName = Literal["ECTI", "STL", "CSM", "KAQ", "GMI"]

class GMIRequest(BaseModel):
    ecti: float = Field(ge=0.0, le=1.0)
    csm: float = Field(ge=0.0, le=1.0)
    stl: float = Field(ge=0.0, le=1.0)
    kaq: float = Field(ge=0.0, le=1.0)

class MetricScore(BaseModel):
    name: MetricName
    value: float = Field(ge=0.0, le=1.0)
    status: Literal["pass", "warn", "fail"]
    explanation: str

class PolicyThresholds(BaseModel):
    min_fidelity: float | None = Field(default=None, ge=0.0, le=1.0)
    max_latency_ms: int | None = Field(default=None, ge=0)
    min_synergy: float | None = Field(default=None, ge=0.0, le=1.0)
    min_alignment: float | None = Field(default=None, ge=0.0, le=1.0)

class PolicyMapping(BaseModel):
    system: str
    action: str

class EthicsPolicy(BaseModel):
    domain: str
    metric: str
    thresholds: PolicyThresholds
    mappings: list[PolicyMapping] = []
    notify_on_drop: bool = True

class PolicyValidationRequest(BaseModel):
    policy_yaml: str

class PolicyValidationResponse(BaseModel):
    valid: bool
    metric: str
    errors: list[str] = []

class HandshakeRequest(BaseModel):
    service_name: str
    service_version: str
    supported_metrics: list[str]
    policy_bundle_hash: str
    transparency_mode: bool = True
    audit_mode: bool = True

class HandshakeResponse(BaseModel):
    accepted: bool
    message: str
    normalized_service: str

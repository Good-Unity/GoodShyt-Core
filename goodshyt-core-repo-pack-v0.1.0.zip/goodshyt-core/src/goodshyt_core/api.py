from fastapi import FastAPI
from .metrics import classify, compute_gmi
from .models import GMIRequest, HandshakeRequest, PolicyValidationRequest, PolicyValidationResponse
from .policies import load_policy_from_yaml, validate_policy
from .protocols import verify_handshake

app = FastAPI(title="GoodShyt Core", version="0.1.0")

@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "goodshyt-core"}

@app.post("/metrics/gmi")
def gmi(payload: GMIRequest) -> dict[str, object]:
    gmi_value = compute_gmi(payload)
    return {"inputs": payload.model_dump(), "gmi": classify("GMI", gmi_value).model_dump()}

@app.post("/policies/validate", response_model=PolicyValidationResponse)
def policies_validate(payload: PolicyValidationRequest) -> PolicyValidationResponse:
    try:
        policy = load_policy_from_yaml(payload.policy_yaml)
        errors = validate_policy(policy)
        return PolicyValidationResponse(valid=not errors, metric=policy.metric, errors=errors)
    except Exception as exc:
        return PolicyValidationResponse(valid=False, metric="unknown", errors=[str(exc)])

@app.post("/handshake/verify")
def handshake_verify(payload: HandshakeRequest) -> dict[str, object]:
    return verify_handshake(payload).model_dump()

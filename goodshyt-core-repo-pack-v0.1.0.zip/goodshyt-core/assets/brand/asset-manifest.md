# Asset Manifest

## Logos
- primary.svg
- icon.png
- mark-dark.svg
- mark-light.svg

## Covers
- github-social.png
- repo-cover.png
- linkedin-banner.png

## Social
- instagram-square-01.png
- instagram-square-02.png
- launch-post.png

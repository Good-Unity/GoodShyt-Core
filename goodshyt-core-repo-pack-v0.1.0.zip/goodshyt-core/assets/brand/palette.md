# Palette

- Forest: #124734
- Orange: #E97B22
- Cream: #F6F1E7
- Charcoal: #0F2F25
- Teal: #1E9BB8
- Leaf: #38A169
- Gold: #F2C94C

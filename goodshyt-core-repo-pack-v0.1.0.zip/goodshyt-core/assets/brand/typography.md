# Typography

- Headlines: Sora or Manrope
- Body: Inter or DM Sans
- Technical fallback: DejaVu Sans

from goodshyt_core.models import HandshakeRequest
from goodshyt_core.protocols import verify_handshake

def test_verify_handshake_accepts_valid_payload() -> None:
    response = verify_handshake(
        HandshakeRequest(service_name="memory", service_version="0.1.0", supported_metrics=["ECTI"], policy_bundle_hash="abc123")
    )
    assert response.accepted is True

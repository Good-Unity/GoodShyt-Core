from goodshyt_core.metrics import compute_gmi
from goodshyt_core.models import GMIRequest

def test_compute_gmi_is_normalized() -> None:
    assert compute_gmi(GMIRequest(ecti=0.98, csm=0.88, stl=0.10, kaq=0.84)) == 0.906

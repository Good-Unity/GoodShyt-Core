# API

- `GET /health`
- `POST /metrics/gmi`
- `POST /policies/validate`
- `POST /handshake/verify`

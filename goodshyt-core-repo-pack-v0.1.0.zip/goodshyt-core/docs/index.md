# GoodShyt Core

Canonical ethics, metrics, protocol, and CLI foundation for the GoodShyt Group ecosystem.

- [Architecture](architecture.md)
- [Quickstart](quickstart.md)
- [API](api.md)
- [Ethics](ethics.md)
- [Branding](branding.md)
- [Roadmap](roadmap.md)

# Ethics

This service is the reference implementation for shared GoodShyt metrics:
ECTI, STL, CSM, KAQ, and GMI.

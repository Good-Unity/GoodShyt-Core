# Roadmap

## v0.1
Repository bootstrap, core application paths, docs, and assets.

## v0.2
External adapters, stricter policy bundles, richer telemetry.

## v0.3
Cross-service integration with broader GoodShyt ecosystem contracts.

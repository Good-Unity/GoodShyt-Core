# Branding

## Product
**GoodShyt Core**

## Tagline
**Ethical Infrastructure Starts Here**

## Palette
- Forest: #124734
- Orange: #E97B22
- Cream: #F6F1E7
- Teal: #1E9BB8
- Leaf: #38A169

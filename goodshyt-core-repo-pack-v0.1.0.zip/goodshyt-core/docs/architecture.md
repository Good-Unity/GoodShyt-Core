# Architecture

The service is split into four concerns:

1. models: typed request and response schemas
2. metrics: deterministic scoring functions
3. policies: YAML loading and threshold validation
4. protocols: compatibility handshake checks

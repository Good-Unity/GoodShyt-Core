---
name: Bug Report
about: Report a defect or regression
title: "[BUG] "
labels: bug
---

## Summary

Describe the bug clearly.

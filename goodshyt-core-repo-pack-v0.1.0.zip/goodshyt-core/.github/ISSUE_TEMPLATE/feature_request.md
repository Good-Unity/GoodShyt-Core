---
name: Feature Request
about: Propose a new capability
title: "[FEAT] "
labels: enhancement
---

## Goal

What outcome should this feature produce?

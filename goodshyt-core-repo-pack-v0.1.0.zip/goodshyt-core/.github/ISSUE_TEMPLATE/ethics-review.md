---
name: Ethics Review
about: Report a concern involving trust, transparency, bias, harm, or system misalignment
title: "[ETHICS] "
labels: ethics
---

## Summary

Describe the concern clearly.

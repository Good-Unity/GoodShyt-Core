## Summary

Describe the change and its intent.

## Validation

- [ ] Tests added or updated
- [ ] Docs updated
- [ ] Ethical or operational impact reviewed

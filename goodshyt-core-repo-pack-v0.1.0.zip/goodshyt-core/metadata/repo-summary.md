# Repository Summary

## Name
GoodShyt Core

## Description
Canonical ethics, metrics, protocol, and CLI foundation for the GoodShyt Group ecosystem.

## Tagline
Ethical Infrastructure Starts Here

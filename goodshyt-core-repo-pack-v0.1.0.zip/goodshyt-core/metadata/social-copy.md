# Social Copy

Introducing **GoodShyt Core** — Canonical ethics, metrics, protocol, and CLI foundation for the GoodShyt Group ecosystem.

**Ethical Infrastructure Starts Here**

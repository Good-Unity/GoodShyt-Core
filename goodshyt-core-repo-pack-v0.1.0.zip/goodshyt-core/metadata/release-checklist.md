# Release Checklist

- [ ] README reviewed
- [ ] Security policy present
- [ ] CI passes
- [ ] Tests pass
- [ ] Asset manifest updated
- [ ] Changelog updated

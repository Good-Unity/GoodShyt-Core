# Changelog

## 0.1.0

- initial repository bootstrap
- working application scaffold
- branded asset pack
- docs and workflows

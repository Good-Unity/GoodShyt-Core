# Code of Conduct

This project is part of the GoodShyt Group ecosystem.

We are committed to building ethical, respectful, community-centered systems.
Contributors are expected to communicate with clarity, accountability, and respect.
